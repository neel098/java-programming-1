package com.neelmani;

import java.util.Arrays;
import java.util.List;

class Employee{
    int empID;
    String empName;
    String empDesignation;
    int empSalary;
    String empLocation;

    public Employee(int empID, String empName, String empDesignation, int empSalary, String empLocation) {
        this.empID = empID;
        this.empName = empName;
        this.empDesignation = empDesignation;
        this.empSalary = empSalary;
        this.empLocation = empLocation;
    }

    public int getEmpID() {
        return empID;
    }

    public void setEmpID(int empID) {
        this.empID = empID;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEmpDesignation() {
        return empDesignation;
    }

    public void setEmpDesignation(String empDesignation) {
        this.empDesignation = empDesignation;
    }

    public int getEmpSalary() {
        return empSalary;
    }

    public void setEmpSalary(int empSalary) {
        this.empSalary = empSalary;
    }

    public String getEmpLocation() {
        return empLocation;
    }

    public void setEmpLocation(String empLocation) {
        this.empLocation = empLocation;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "empID=" + empID +
                ", empName='" + empName + '\'' +
                ", empDesignation='" + empDesignation + '\'' +
                ", empSalary='" + empSalary + '\'' +
                ", empLocation='" + empLocation + '\'' +
                '}';
    }
}

public class Main {

    public static void main(String[] args) {
	// write your code here
        List<Employee> employees = Arrays.asList(
                new Employee(101,"Neel","CEO",55000000,"Varanasi"),
                new Employee(102,"Arvind","CO-CEO",10000,"Patna"),
                new Employee(103,"Tanisha","Sponsorship Executive",500000,"Ranchi"),
                new Employee(105,"Sam","CMO",700000,"Kolkata"),
                new Employee(106,"Arshad","CTO",400000,"Bihar"),
                new Employee(104,"Aarti","Public Relation",45000,"Dehradun"),
                new Employee(107,"Divyank","Event Manager",75000,"Muzzafarnagar"),
                new Employee(108,"Rohit","Associate Director",785333,"Bharatpur"),
                new Employee(109,"Sukhvinder","CFO",67838,"Haryana"),
                new Employee(110,"Vidyarthi","Managing Director",89000,"Jharkhand")
        );

        //Printing the names of all Employees
        System.out.println("\nNames of all Employees\n");
        employees.stream().forEach(e-> System.out.println(e.getEmpName()));

        //Employees Salary Greater than 50,000
        System.out.println("\nEmployee Salary Greater than 50000\n");
        employees.stream().filter(e->e.getEmpSalary() > 50000).forEach(e-> System.out.println(e.getEmpName()+" "+" "+e.getEmpSalary()));

        //Location Starting with Letter M
        System.out.println("\nLocation Starting with Letter M\n");
        employees.stream().filter(e->e.getEmpLocation().startsWith("M")).forEach(e-> System.out.println(e.getEmpLocation()));

        //Designation Ending with E
        System.out.println("\nDesignation Ending with E\n");
        employees.stream().filter(e->e.getEmpDesignation().endsWith("E")).forEach(e-> System.out.println(e.getEmpDesignation()));
    }
}
