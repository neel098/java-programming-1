package com.neelmani;

class GenericMethod<T>{
    public T numberString(T number){
        try{
            if (Integer.parseInt(number))
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

public class Main {

    public static void main(String[] args) {
	// write your code here

    }
}
