package com.neelmani;

public class Calculator {
    interface operation{
        int calculator(int a, int b);
    }
}
