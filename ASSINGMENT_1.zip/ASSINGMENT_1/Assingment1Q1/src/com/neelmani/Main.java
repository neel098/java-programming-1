package com.neelmani;


public class Main {

    public static void main(String[] args) {
        // write your code here
        Calculator.operation add = (a, b) -> a + b;
        Calculator.operation subtract = (a, b) -> a - b;
        Calculator.operation multiply = (a, b) -> a - b;
        Calculator.operation divide = (a, b) -> {
            if (b != 0) {
                return a / b;
            }
            return 0;
        };
        System.out.println(add.calculator(10, 5));
        System.out.println(subtract.calculator(10, 5));
        System.out.println(multiply.calculator(10, 5));
        System.out.println(divide.calculator(10, 5));

    }
}
