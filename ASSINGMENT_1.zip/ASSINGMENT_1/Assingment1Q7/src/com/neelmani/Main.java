package com.neelmani;
import java.lang.Math;
import java.util.Scanner;

class Triangle {

    public double getArea(double a, double b, double c) {

        double semiParameter = (a + b + c) / 2;
        double areaTriangle = Math.sqrt(Math.abs(semiParameter * (semiParameter - a) * (semiParameter - b) * (semiParameter - c)));

        return areaTriangle;
    }
}

public class Main {

    public static void main(String[] args) {
        // write your code here
        Triangle triangle = new Triangle();
        Scanner scanner = new Scanner(System.in);

        double sideA = scanner.nextDouble();
        double sideB = scanner.nextDouble();
        double sideC = scanner.nextDouble();

        double result = triangle.getArea(sideA,sideB,sideC);
        System.out.println("Area of Triangle: "+ result);
    }
}
