package com.neelmani;

import java.util.Scanner;

class Rectangle {

    double height;
    double width;

    public void display() {
        System.out.println("Height: " + this.height + " " + "Width: " + this.width);
    }
}

class RectangleArea extends Rectangle{
    public void read_input(){
        Scanner scanner = new Scanner(System.in);
        height = scanner.nextDouble();
        width = scanner.nextDouble();

    }

    public void display(){
        System.out.println("Area of the Rectangle: "+ height*width);
    }
}

public class Main {

    public static void main(String[] args) {
	// write your code here

        Rectangle rectangle = new Rectangle();
        RectangleArea rectangleArea = new RectangleArea();


        rectangleArea.read_input();
        rectangleArea.display();
        rectangle.display();
    }
}
