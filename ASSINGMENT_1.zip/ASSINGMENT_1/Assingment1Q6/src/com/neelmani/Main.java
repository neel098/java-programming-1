package com.neelmani;

import java.util.Scanner;

class Employee {
    int year_of_joining;
    float salary;
    String name;
    String address;


    public void getInput() {
        Scanner scanner = new Scanner(System.in);
        year_of_joining = scanner.nextInt();
        name = scanner.next();
        salary = scanner.nextFloat();
        address = scanner.next();
    }

    public void display() {
        System.out.println(name + "          " + year_of_joining + "       " + salary + "  " + address);

    }
}

public class Main {

    public static void main(String[] args) {
        // write your code here//
        Employee[] employee = new Employee[3];
        for (int i = 0; i < 3; i++) {
            employee[i] = new Employee();
            employee[i].getInput();
        }

        System.out.println("Name    Year of Joining    Salary    Address");
        for (int i = 0; i < 3; i++) {
            employee[i].display();
        }
    }
}
